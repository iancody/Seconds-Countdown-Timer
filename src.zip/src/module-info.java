/**
 * 
 */
/**
 * 
 */
module Practice {
}